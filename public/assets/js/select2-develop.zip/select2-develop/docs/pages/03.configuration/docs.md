---
title: Configuration
taxonomy:
    category: docs
---

To configure custom options when you initialize Select2, simply pass an object in your call to `.select2()`:

```
$('.js-example-basic-single').select2({
  placeholder: 'Select an option'
});
```
