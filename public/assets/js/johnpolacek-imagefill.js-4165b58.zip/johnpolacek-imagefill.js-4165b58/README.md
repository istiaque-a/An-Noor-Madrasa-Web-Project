# imagefill.js
## The jQuery plugin for making an image fill its container (and be centered)
by [John Polacek](http://johnpolacek.com)

See demo and documentation at the [project page](http://johnpolacek.github.io/imagefill.js)

Requires imagesLoaded - https://github.com/desandro/imagesloaded

For a jQuery-free version of this plugin, go to:
https://github.com/StudioThick/imagefill.js

* * *
#### follow [@johnpolacek](https://twitter.com/johnpolacek)
* * *


## Legal
Author & copyright (c) 2013: [John Polacek](http://johnpolacek.com), Dual MIT & GPL license
